import React, { useRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";

const concernsData = [
  {
    title: "ABC Developers Ltd.",
    description:
      "Pioneering advancements in manufacturing, ABC Developers Ltd. stands as a beacon of innovation in the industrial sector.",
    image: "path-to-your-image.jpg",
  },
  {
    title: "ABC Holdings Ltd.",
    description:
      "As the investment arm of the group, ABC Holdings Ltd. plays a pivotal role in identifying strategic opportunities and nurturing emerging ventures.",
    logo: "logoipsum.png",
  },
  {
    title: "ABC AgroTech Solutions",
    description:
      "Focused on agricultural innovation and sustainability, ABC AgroTech Solutions leverages cutting-edge technologies to optimize crop yields.",
    logo: "logoipsum2.png",
  },
  {
    title: "ABC Healthcare Ltd.",
    description:
      "Its comprehensive network delivers world-class facilities to improve access to healthcare for all.",
    logo: "logoipsum3.png",
  },
];

const ConcernCard = ({ concern }) => {
  return (
    <div className="group p-4 bg-white shadow-lg rounded-lg hover:shadow-xl transition duration-300 ease-in-out transform hover:scale-105">
      <div className="relative">
        <img
          src={concern.image || concern.logo}
          alt={concern.title}
          className="w-full h-40 object-cover rounded-lg group-hover:opacity-80 transition-opacity duration-300"
        />
      </div>
      <h3 className="mt-4 text-lg font-semibold">{concern.title}</h3>
      <p className="text-sm text-gray-500 mt-2">{concern.description}</p>
    </div>
  );
};

const ConcernsSlider = () => {
  const sliderRef = useRef(null);

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: false, // Disable default arrows
  };

  const handlePrevClick = () => {
    if (sliderRef.current) {
      sliderRef.current.slickPrev();
    }
  };

  const handleNextClick = () => {
    if (sliderRef.current) {
      sliderRef.current.slickNext();
    }
  };

  return (
    <div className="container mx-auto p-16">
      <div className="w-full h-1 bg-gray-200 mb-4">
        <div className="h-full bg-orange-500 w-1/12"></div>{" "}
      </div>
      <div className="flex justify-between">
        <h2 className="text-5xl font-bold mb-4">Our Concerns</h2>
        <div className="flex items-start gap-4">
          <div className="flex">
            <button
              onClick={handlePrevClick}
              className="text-black hover:text-gray-400 p-2"
            >
              <FaArrowLeft size={16} />
            </button>
            <div>
              <button
                onClick={handleNextClick}
                className="text-black hover:text-gray-400 p-2"
              >
                <FaArrowRight size={16} />
              </button>
            </div>
          </div>
          <button>View All</button>
        </div>
      </div>
      <Slider ref={sliderRef} {...settings}>
        {concernsData.map((concern, index) => (
          <ConcernCard key={index} concern={concern} />
        ))}
      </Slider>
      <div className="mt-4 flex justify-end">
        <button className="text-gray-700 hover:text-gray-900">
          View All <span aria-hidden="true">→</span>
        </button>
      </div>
    </div>
  );
};

export default ConcernsSlider;
