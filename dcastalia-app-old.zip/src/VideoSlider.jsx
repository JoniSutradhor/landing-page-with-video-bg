import React, { useState, useEffect, useContext } from "react";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import Navbar from "./Navbar";
import { DataContext } from './contexts/DataContext';

const slides = [
  {
    video: "https://www.w3schools.com/html/mov_bbb.mp4", // Sample video link
    title: "History of expertise.",
    subtitle: "Reputation for excellence.",
    description:
      "Lorem ipsum dolor sit amet consectetur adipiscing elit. Maxime mollitia.",
  },
  {
    video: "https://www.w3schools.com/html/movie.mp4", // Another sample video link
    title: "Leaders of Innovation.",
    subtitle: "Building the future.",
    description:
      "Lorem ipsum dolor sit amet consectetur adipiscing elit. Maxime mollitia.",
  },
  // Add more slides here
];

const VideoSlider = () => {
  const { data, loading, error } = useContext(DataContext);
  console.log("DATA : ",data?.data?.sections.filter((section)=> section?.section_data?.template === "slider_template"))
  const [currentSlide, setCurrentSlide] = useState(0);

  const totalSlides = slides.length;

  const nextSlide = () => {
    setCurrentSlide((prevSlide) =>
      prevSlide === totalSlides - 1 ? 0 : prevSlide + 1
    );
  };

  const prevSlide = () => {
    setCurrentSlide((prevSlide) =>
      prevSlide === 0 ? totalSlides - 1 : prevSlide - 1
    );
  };

  // Auto-slide every 10 seconds
  useEffect(() => {
    const slideInterval = setInterval(nextSlide, 10000);
    return () => clearInterval(slideInterval);
  }, []);

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Video Background */}
      {slides.map((slide, index) => (
        <video
          key={index}
          className={`absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
          autoPlay
          loop
          muted
          src={slide.video}
        />
      ))}

      {/* Overlay Content */}
      <div className="relative z-10 h-full text-white">
        <Navbar bgStyle={"transparent"} />
        <div className="flex flex-col h-full justify-around">
          <div className="pl-16">
            <p className="text-sm uppercase mb-2">Leaders of Innovation</p>
            <h1 className="text-6xl font-bold leading-tight mb-4">
              {slides[currentSlide].title}
            </h1>
            <h2 className="text-3xl font-semibold mb-4">
              {slides[currentSlide].subtitle}
            </h2>
          </div>

          {/* Bottom Left - Slide Number and Progress Bar */}
          <div className="text-white flex flex-col px-16 gap-4">
            {/* Updated to show "2 of 5" style text */}
            <div className="text-2xl mr-4">{`${currentSlide + 1 < 10 ? `0${currentSlide + 1}` : currentSlide + 1}`}</div>
            <div className="relative w-full h-1 bg-white bg-opacity-30">
              <div
                className="h-full bg-white transition-all duration-1000"
                // Adjust width based on current slide
                style={{
                  width: `${((currentSlide + 1) / totalSlides) * 100}%`,
                }}
              ></div>
            </div>
            <div className="flex justify-between">
              <div>
                <button
                  onClick={prevSlide}
                  className=" text-white hover:text-gray-400"
                >
                  <FaArrowLeft size={24} />
                </button>
                <button
                  onClick={nextSlide}
                  className="p-2 text-white hover:text-gray-400"
                >
                  <FaArrowRight size={24} />
                </button>
              </div>
              {/* Bottom Right - Description */}
              <div className=" text-white max-w-xs text-right">
                <p className="text-sm">{slides[currentSlide].description}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoSlider;
